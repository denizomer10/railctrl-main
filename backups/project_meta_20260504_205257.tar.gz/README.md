# RailCtrl (Lokal AstroDB Sürümü)

RailCtrl, istasyon operasyonları için geliştirilmiş Astro tabanlı bir yönetim uygulamasıdır.
Bu branch (`astro-db-migration`) PostgreSQL bağımlılığını kaldırıp AstroDB (libSQL/SQLite) ile lokal çalışmayı hedefler.

## Gereksinimler

- Node.js `>= 22.12.0`
- npm `>= 10`

Kontrol:

```bash
node -v
npm -v
```

## Kurulum

```bash
git checkout astro-db-migration
npm install
cp .env.example .env
```

## Ortam Değişkenleri

`.env` içinde:

```env
NODE_ENV=production
PORT=3000

ASTRO_DB_REMOTE_URL=
ASTRO_DB_APP_TOKEN=

JWT_SECRET=change-this-jwt-secret
ENCRYPTION_KEY=change-this-32-char-key
```

Not:
- Sadece lokal geliştirme yapacaksan `ASTRO_DB_REMOTE_URL` ve `ASTRO_DB_APP_TOKEN` boş kalabilir.
- Lokal DB dosyası için komutlarda `ASTRO_DATABASE_FILE=.astro/content.db` kullanıyoruz.

## Lokal Çalıştırma

```bash
npm run dev
```

Uygulama:
- `http://localhost:3000`

## Build

```bash
ASTRO_DATABASE_FILE=.astro/content.db npm run build
```

## PostgreSQL Backup -> AstroDB Durumu

Kullanılan kaynak backup:
- `backups/railctrl_backup_20260228_221435.sql`

Mevcut durum (2026-05-03):
- PostgreSQL dump dosyasından AstroDB'ye tablo + veri aktarımı tamamlandı.
- Aşağıdaki örnek doğrulama sayımları alındı:
  - `users`: 7
  - `mms_records`: 2190
  - `calisma_izinleri`: 68
  - `kayip_esya`: 768
  - `notlar`: 12
  - `dahili_numaralar`: 81
  - `vardiyalar`: 8

Not:
- PostgreSQL'e özgü sözdizimi (`COPY`, `SEQUENCE`, trigger/function DDL vb.) dönüşüm gerektirdiği için import scripti dump'ı parse edip SQLite/libSQL uyumlu şekilde yazar.

Bu branch'te uygulama yerel Node adapter ile build alır ve backup verisi AstroDB'ye aktarılmış durumdadır.